// 2-argument.js

function myFunction(){
	console.log(arguments);
}

myFunction(3,6,9,12,15);

//argument is all parameter that pass to the current function