// 3-wrapper.js

//function(exports, require, module, _filename, __dirname){

	exports.a =21; //module.exports

	exports.display = () => {
		console.log('I am from wrapper.js module');
	}

	let score = 10;

	// console.log(arguments);
	// console.log(exports);
	// console.log(module.exports);


	//returns module.exports; // or returns exports


//}



