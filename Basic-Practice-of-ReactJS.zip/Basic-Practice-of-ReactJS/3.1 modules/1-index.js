// 1-index.js

console.log(`hello node`);

//this is also module
//node wrap this into function and run it


