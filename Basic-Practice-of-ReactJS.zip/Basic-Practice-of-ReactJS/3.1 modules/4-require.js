// 4-require.js

const myModule = require('./3-wrapper');

console.log(myModule.a)

myModule.display();

