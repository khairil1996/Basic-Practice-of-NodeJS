const myFunc = (param1, param2)=>{

	console.log(param1 + ' .it rocks. ' + param2)

}

setTimeout(myFunc, 2*1000, 'khairil', 'is great');

//myFunc (arg1, arg2,arg3, ...)

//setTimeout(myFunc, 5*1000,'a','b',1,2,3)
//a will be parameter of the function