// 1-setTimeout-example.js

// setTimeout(func, timeInMilles);
setTimeout(()=>{

	console.log('hello after 4 seconds')

}, 4*1000);