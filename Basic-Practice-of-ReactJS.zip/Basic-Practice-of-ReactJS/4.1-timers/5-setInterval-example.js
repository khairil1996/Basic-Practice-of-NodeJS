// 5-setInterval-example.js

setInterval(
	()=> console.log('hello every 4 seconds'),
	4000
	)