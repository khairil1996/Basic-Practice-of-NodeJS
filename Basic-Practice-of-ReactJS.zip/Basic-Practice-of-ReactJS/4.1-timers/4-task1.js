//task
//hello after 5 sec
//hello after 10 sec
//you can define only 1 function

//my solution
// for (let i=5; i<=10; i=i+5){
// 	const myFunc = ()=>{console.log(`hello after ${i} seconds`)}
// 	setTimeout(myFunc, i*1000);
// }

const myFunc = () => {};

setTimeout(myFunc, 5*1000);


