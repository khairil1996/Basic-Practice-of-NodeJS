// 2-interval

setInterval(() => {
	console.log('hello event loop!!')
}, 5000)