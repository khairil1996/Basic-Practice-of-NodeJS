// 1-log.js

console.log('who needs the event loop!!')

