//object literals 3

const bear = 'animal';
const PI = Math.PI;

const myObject = {

	[bear]: 'wild', // bear will be replaced by 'animal'
	PI //PI:PI

};

myObject.propertyZ = true; //add new property into object

myObject['propertyX'] = 21; //add new property into object

myObject.PI;

