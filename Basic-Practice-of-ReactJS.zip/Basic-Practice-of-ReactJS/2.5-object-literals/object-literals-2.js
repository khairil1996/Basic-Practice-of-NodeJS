//object-literals-2

const myObject = {
	nameL 'Sriyank',
	age:27,

	onSwap: funtion(){ //regular func
		//code here
	},
	onClick(){ //regular func
		//code here
		//same as above
	},

	myFunc: ()=>{ //arrow function
		//code here
	},
};

myObject.onSwap();
myObject.onClick();
myObject.myFunc();